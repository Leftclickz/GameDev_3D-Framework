#include "GamePCH.h"

#include "Mesh/Mesh.h"
#include "GameObjects/GameObject.h"

GameObject::GameObject(Game* pGame, Mesh* pMesh, ShaderProgram* pShader, Texture* pTexture)
: m_pGame( pGame )
, m_pShader( pShader )
, m_pMesh( pMesh )
, m_pTexture( pTexture )
, m_Position( 0, 0 )
, m_Angle( 0 )
, m_Radius( 0.5f )
{
}

GameObject::~GameObject()
{
}

void GameObject::Draw(vec2 camPos, vec2 projScale)
{
    if( m_pMesh != nullptr )
    {
        m_pMesh->SetupAttributes( m_pShader );
        m_pMesh->SetupUniforms( m_pShader, m_Position, m_Angle, 1, camPos, projScale, m_pTexture );
        m_pMesh->Draw( m_pShader );
    }
}
