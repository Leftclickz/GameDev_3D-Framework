#ifndef __Game_H__
#define __Game_H__

class Texture;
class Mesh;
class GameObject;
class Player;
class PlayerController;

class Game : public GameCore
{
protected:
    ShaderProgram* m_pShader;
    Texture* m_pTexture;
    Mesh* m_pMeshBox;

    PlayerController* m_pControllers[4];

    Player* m_pPlayer;

public:
    Game(Framework* pFramework);
    virtual ~Game();

    virtual void OnSurfaceChanged(unsigned int width, unsigned int height) override;
    virtual void LoadContent() override;

    virtual void OnEvent(Event* pEvent) override;
    virtual void Update(float deltatime) override;
    virtual void Draw() override;

    PlayerController* GetController(int index) { return m_pControllers[index]; }
};

#endif //__Game_H__
