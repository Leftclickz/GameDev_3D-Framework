#include "GamePCH.h"

#include "Game/Game.h"
#include "Mesh/Mesh.h"
#include "Mesh/Texture.h"
#include "GameObjects/GameObject.h"
#include "GameObjects/Player.h"
#include "GameObjects/PlayerController.h"

Game::Game(Framework* pFramework)
: GameCore( pFramework, new EventManager() )
{
    m_pShader = nullptr;
    m_pTexture = nullptr;
    m_pMeshBox = nullptr;

    for( int i=0; i<4; i++ )
    {
        m_pControllers[i] = nullptr;
    }

    m_pPlayer = nullptr;
}

Game::~Game()
{
    delete m_pPlayer;

    for( int i=0; i<4; i++ )
    {
        delete m_pControllers[i];
    }

    delete m_pMeshBox;
    delete m_pTexture;
    delete m_pShader;
}

void Game::OnSurfaceChanged(unsigned int width, unsigned int height)
{
    // Set OpenGL to draw to the entire window.
    glViewport( 0, 0, width, height );
}

void Game::LoadContent()
{
#if WIN32
    // Turn on V-Sync.
    wglSwapInterval( 1 );
#endif

    // Turn on depth buffer testing.
    glEnable( GL_DEPTH_TEST );
    glDepthFunc( GL_LEQUAL );

    // Turn on alpha blending.
    glEnable( GL_BLEND );
    glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

    // Create our shaders.
    m_pShader = new ShaderProgram( "Data/Shaders/Texture.vert", "Data/Shaders/Texture.frag" );

    // Load some textures.
    m_pTexture = new Texture( "Data/Textures/Megaman.png" );

    // Create our meshes.
    m_pMeshBox = new Mesh();
    m_pMeshBox->CreateBox( vec2(1,1), vec2(0,0) );

    // Create our controllers.
    for( int i=0; i<4; i++ )
    {
        m_pControllers[i] = new PlayerController();
    }

    // Populate our scene.
    m_pPlayer = new Player( this, m_pMeshBox, m_pShader, m_pTexture );
    m_pPlayer->SetPlayerController( m_pControllers[0] );

    CheckForGLErrors();
}

void Game::OnEvent(Event* pEvent)
{
    m_pControllers[0]->OnEvent( pEvent );

#if WIN32
    // Enable/Disable V-Sync with F1 and F2.
    if( pEvent->GetEventType() == EventType_Input )
    {
        InputEvent* pInput = (InputEvent*)pEvent;

        // Enable V-Sync.
        if( pInput->GetInputDeviceType() == InputDeviceType_Keyboard && pInput->GetID() == VK_F1 )
            wglSwapInterval( 1 );

        // Disable V-Sync.
        if( pInput->GetInputDeviceType() == InputDeviceType_Keyboard && pInput->GetID() == VK_F2 )
            wglSwapInterval( 0 );
    }
#endif //WIN32
}

void Game::Update(float deltatime)
{
    m_pPlayer->Update( deltatime );
}

void Game::Draw()
{
    // Setup the values we will clear to, then actually clear the color and depth buffers.
    glClearColor( 0.0f, 0.0f, 0.4f, 0.0f ); // (red, green, blue, alpha) - dark blue.
#if WIN32
    glClearDepth( 1 ); // 1 is maximum depth.
#endif
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    vec2 halfWorldSize = vec2( 5.0f, 5.0f );

    // Draw our game objects.
    m_pPlayer->Draw( halfWorldSize, 1/halfWorldSize );

    CheckForGLErrors();
}
