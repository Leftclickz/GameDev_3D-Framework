#ifndef __WinMain_H__
#define __WinMain_H__

#endif //__WinMain_H__
