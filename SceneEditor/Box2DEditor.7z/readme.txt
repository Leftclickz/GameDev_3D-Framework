MyEngine� is a free open-source cross-platform game engine.

Find more info here: www.FlatheadGames.com/myengine.php
Find the source here: www.github.com/JimmyLord
